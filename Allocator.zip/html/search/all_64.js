var searchData=
[
  ['deallocate',['deallocate',['../classAllocator.html#a8823b257191f53d7f1efac9332d8f61a',1,'Allocator::deallocate(pointer p, size_type)'],['../classAllocator.html#a8823b257191f53d7f1efac9332d8f61a',1,'Allocator::deallocate(pointer p, size_type)']]],
  ['destroy',['destroy',['../classAllocator.html#af156a6a50a8c62c70e40cf342a3b64cb',1,'Allocator::destroy(pointer p)'],['../classAllocator.html#af156a6a50a8c62c70e40cf342a3b64cb',1,'Allocator::destroy(pointer p)']]],
  ['difference_5ftype',['difference_type',['../classAllocator.html#a6b650764260187e63d5098f5f38046c2',1,'Allocator::difference_type()'],['../classAllocator.html#a6b650764260187e63d5098f5f38046c2',1,'Allocator::difference_type()'],['../structTestAllocator.html#ac3c65cec130a0c773dba9cd64477b72d',1,'TestAllocator::difference_type()']]]
];
