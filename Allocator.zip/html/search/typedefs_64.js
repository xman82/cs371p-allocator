var searchData=
[
  ['difference_5ftype',['difference_type',['../classAllocator.html#a6b650764260187e63d5098f5f38046c2',1,'Allocator::difference_type()'],['../classAllocator.html#a6b650764260187e63d5098f5f38046c2',1,'Allocator::difference_type()'],['../structTestAllocator.html#ac3c65cec130a0c773dba9cd64477b72d',1,'TestAllocator::difference_type()']]]
];
