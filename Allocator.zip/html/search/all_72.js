var searchData=
[
  ['reference',['reference',['../classAllocator.html#adf0658602f352de03fa2d2c4f23903e9',1,'Allocator::reference()'],['../classAllocator.html#adf0658602f352de03fa2d2c4f23903e9',1,'Allocator::reference()']]]
];
