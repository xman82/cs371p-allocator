var searchData=
[
  ['deallocate',['deallocate',['../classAllocator.html#a8823b257191f53d7f1efac9332d8f61a',1,'Allocator::deallocate(pointer p, size_type)'],['../classAllocator.html#a8823b257191f53d7f1efac9332d8f61a',1,'Allocator::deallocate(pointer p, size_type)']]],
  ['destroy',['destroy',['../classAllocator.html#af156a6a50a8c62c70e40cf342a3b64cb',1,'Allocator::destroy(pointer p)'],['../classAllocator.html#af156a6a50a8c62c70e40cf342a3b64cb',1,'Allocator::destroy(pointer p)']]]
];
