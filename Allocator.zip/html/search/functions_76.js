var searchData=
[
  ['valid',['valid',['../classAllocator.html#a45091854a38a5abf184cc442d2af4022',1,'Allocator::valid() const '],['../classAllocator.html#a45091854a38a5abf184cc442d2af4022',1,'Allocator::valid() const ']]],
  ['view',['view',['../classAllocator.html#a0ea92631b6476ecfb735724daa6271b8',1,'Allocator::view(char &amp;c)'],['../classAllocator.html#a05e08c68e56d09807615973002475423',1,'Allocator::view(int &amp;i)'],['../classAllocator.html#aad1b14fd9a73456468cf0c8dfb62c211',1,'Allocator::view(int i) const '],['../classAllocator.html#a0ea92631b6476ecfb735724daa6271b8',1,'Allocator::view(char &amp;c)'],['../classAllocator.html#a05e08c68e56d09807615973002475423',1,'Allocator::view(int &amp;i)'],['../allocator_8h.html#aac4686ee49c3005d72ed3a9637858a5f',1,'view():&#160;allocator.h']]]
];
