var searchData=
[
  ['operator_21_3d',['operator!=',['../classAllocator.html#aa59693ec7b26e5ee0a2a4bc71db20040',1,'Allocator::operator!=()'],['../classAllocator.html#aa59693ec7b26e5ee0a2a4bc71db20040',1,'Allocator::operator!=()']]],
  ['operator_3d_3d',['operator==',['../classAllocator.html#ad178871e3d4888c233e0a39e2fe36982',1,'Allocator::operator==()'],['../classAllocator.html#ad178871e3d4888c233e0a39e2fe36982',1,'Allocator::operator==()']]]
];
