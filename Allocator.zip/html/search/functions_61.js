var searchData=
[
  ['allocate',['allocate',['../classAllocator.html#a8a19b7b675f5434c28c68fb15de86f36',1,'Allocator::allocate(size_type n)'],['../classAllocator.html#a8a19b7b675f5434c28c68fb15de86f36',1,'Allocator::allocate(size_type n)']]],
  ['allocator',['Allocator',['../classAllocator.html#a4e2bf5fbf94e2206bb72b71ad4b7ffb3',1,'Allocator::Allocator()'],['../classAllocator.html#a4e2bf5fbf94e2206bb72b71ad4b7ffb3',1,'Allocator::Allocator()']]]
];
