var searchData=
[
  ['size_5ftype',['size_type',['../classAllocator.html#aec4c70d3e80d2b7d11bbb8bd8a62f016',1,'Allocator::size_type()'],['../classAllocator.html#aec4c70d3e80d2b7d11bbb8bd8a62f016',1,'Allocator::size_type()']]],
  ['sntl_5fsize',['sntl_size',['../classAllocator.html#a20632af129264517a8badd40647a2047',1,'Allocator']]]
];
