var searchData=
[
  ['pointer',['pointer',['../classAllocator.html#a7df4693123ad6d168217e3853cd15495',1,'Allocator::pointer()'],['../classAllocator.html#a7df4693123ad6d168217e3853cd15495',1,'Allocator::pointer()'],['../structTestAllocator.html#a77c16c448bacf290ba630694fe9e4358',1,'TestAllocator::pointer()']]]
];
