var searchData=
[
  ['const_5fpointer',['const_pointer',['../classAllocator.html#a5815a9c01f756005eb19d0ae5aded3be',1,'Allocator::const_pointer()'],['../classAllocator.html#a5815a9c01f756005eb19d0ae5aded3be',1,'Allocator::const_pointer()']]],
  ['const_5freference',['const_reference',['../classAllocator.html#aff863afcf191fb225997ae2d51314bf5',1,'Allocator::const_reference()'],['../classAllocator.html#aff863afcf191fb225997ae2d51314bf5',1,'Allocator::const_reference()']]]
];
