var searchData=
[
  ['min_5fblk',['min_blk',['../classAllocator.html#a354804aae6d06863ebcd59949e5f59d6',1,'Allocator']]]
];
