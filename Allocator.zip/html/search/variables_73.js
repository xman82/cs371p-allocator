var searchData=
[
  ['sntl_5fsize',['sntl_size',['../classAllocator.html#a20632af129264517a8badd40647a2047',1,'Allocator']]]
];
