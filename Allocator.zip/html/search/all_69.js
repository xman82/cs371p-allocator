var searchData=
[
  ['isvalid',['isValid',['../classAllocator.html#a3787e007291737fb9ed49b18028d770a',1,'Allocator']]]
];
