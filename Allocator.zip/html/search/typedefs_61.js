var searchData=
[
  ['allocator_5ftype',['allocator_type',['../structTestAllocator.html#af8efd777e4901f5fe89963b705a9ec46',1,'TestAllocator']]]
];
